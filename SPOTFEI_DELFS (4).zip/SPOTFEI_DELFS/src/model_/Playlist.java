
package model_;


public class Playlist {
    private String nome;
    private String descricao;
    private int idUsuario;

  public Playlist(String nome, int idUsuario) {
    this.nome = nome;
    this.idUsuario = idUsuario;
}

    
    public Playlist() {
    // construtor vazio para facilitar criação do objeto e depois setar os campos
}


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
}

package model_;


public class Musica {
    private int id;
    private String titulo;
    private String artista;
    private String genero;
    private String duracao;
    private int visualizacoes;
    private String dataPostagem;
    private boolean curtido;
    
    public Musica(int id, String titulo, String artista, String genero,
                  String duracao, int visualizacoes, String dataPostagem, boolean curtido) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
        this.duracao = duracao;
        this.visualizacoes = visualizacoes;
        this.dataPostagem = dataPostagem;
        this.curtido = curtido;
    }

    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getArtista() { return artista; }
    public String getGenero() { return genero; }
    public String getDuracao() { return duracao; }
    public int getVisualizacoes() { return visualizacoes; }
    public String getDataPostagem() { return dataPostagem; }
    public Boolean getCurtido() { return curtido; }
    
    @Override
    public String toString() {
    return titulo + " - " + artista + " (" + genero + ")";
    }

    public void setCurtido(boolean b) {
       
    }
}


package model_;

import java.time.LocalDateTime;

public class Historico {
    private int id;
    private int idUsuario;
    private int idMusica;
    private String tipo; // "curtida", "descurtida", "buscada"
    private LocalDateTime dataHora;

    public Historico(int idUsuario, int idMusica, String tipo) {
        this.idUsuario = idUsuario;
        this.idMusica = idMusica;
        this.tipo = tipo;
        this.dataHora = LocalDateTime.now();
    }

    public Historico() {
       
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdMusica() {
        return idMusica;
    }
    public void setIdMusica(int idMusica) {
        this.idMusica = idMusica;
    }

    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }
    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
}

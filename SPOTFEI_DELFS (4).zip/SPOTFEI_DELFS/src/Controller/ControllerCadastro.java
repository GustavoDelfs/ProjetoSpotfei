package controller;

import DAO.UserDAO;
import DAO.BD_Link;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model_.User;
import View.CadastroFrame;

public class ControllerCadastro {
    private CadastroFrame view;
    
    public ControllerCadastro(CadastroFrame view){
        this.view = view;
    }
    
    public void salvarUsuario() {
        String nome = view.getTxt_nome_cadastro().getText();
        String usuario = view.getTxt_usuario_cadastro().getText();
        String senha = view.getTxt_senha_cadastro().getText();

        User usuarioLogado = new User(nome, usuario, senha);

        BD_Link bd_link = new BD_Link();
        try {
            Connection conn = bd_link.getConnection();
            UserDAO dao = new UserDAO(conn);
            dao.inserir(usuarioLogado);
            JOptionPane.showMessageDialog(view, "Usuário cadastrado com sucesso!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(view, "Erro ao cadastrar usuário!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}


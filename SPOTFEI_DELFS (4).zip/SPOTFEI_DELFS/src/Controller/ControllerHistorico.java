package Controller;

import DAO.BD_Link;
import DAO.HistoricoDAO;
import View.HistoricoFrame;
import controller.ControllerLogin; // ✅ Corrigido para maiúsculo
import model_.User;              // ✅ Adicionado para reconhecer o tipo Usuario

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ControllerHistorico {
    private HistoricoFrame view;
    private HistoricoDAO historicoDAO;

    public ControllerHistorico(HistoricoFrame view) {
        this.view = view;
        try {
            Connection conn = new BD_Link().getConnection();
            historicoDAO = new HistoricoDAO(conn);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco.");
        }
    }

    public void carregarHistorico(int idUsuario) {
        try {
            // Obter o usuário logado
            User usuarioLogado = ControllerLogin.getUsuarioLogado();
            if (usuarioLogado == null) {
                JOptionPane.showMessageDialog(null, "Nenhum usuário logado.");
                return;
            }

//            int idUsuario = usuarioLogado.getId()

            // Buscar dados
            List<String> historico_curtidas = historicoDAO.getUltimasCurtidas(idUsuario);
            List<String> historico_descurtidas = historicoDAO.getUltimasDescurtidas(idUsuario);
            List<String> historico_buscas = historicoDAO.getUltimasBuscas(idUsuario);

            // Exibir nas listas
            view.getjList1().setListData(historico_buscas.toArray(new String[0]));
            view.getjList2().setListData(historico_descurtidas.toArray(new String[0]));
            view.getjList3().setListData(historico_curtidas.toArray(new String[0]));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar histórico: " + e.getMessage());
        }
    }
}

package controller;

import DAO.UserDAO;
import DAO.BD_Link;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model_.User;
import View.AltExcFrame;

public class ControllerUsuario {
    private AltExcFrame view;
    private User usuarioLogado;

    public ControllerUsuario(AltExcFrame view, User usuarioLogado) {
        this.view = view;
        this.usuarioLogado = usuarioLogado;
    }
    
    public void atualizar() {
        String novaSenha = view.getTxt_senha_altexc().getText();
        String nomeUsuario = view.getLbl_usuario_altexc().getText();

        User usuarioAtualizado = new User("", nomeUsuario, novaSenha);

        BD_Link bd_link = new BD_Link();
        try {
            Connection conn = bd_link.getConnection();
            UserDAO dao = new UserDAO(conn);
            dao.atualizar(usuarioAtualizado);
            JOptionPane.showMessageDialog(view, "Senha de Usuário atualizada com Sucesso!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(view, "Falha de conexão!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void remover() {
        String nomeUsuario = usuarioLogado.getUsuario();

        int option = JOptionPane.showConfirmDialog(view, "Deseja realmente excluir o cadastro?",
                "Aviso", JOptionPane.YES_NO_OPTION);

        if (option == JOptionPane.YES_OPTION) {
            BD_Link bd_link = new BD_Link();
            try {
                Connection conn = bd_link.getConnection();
                UserDAO dao = new UserDAO(conn);
                dao.remover(usuarioLogado);
                JOptionPane.showMessageDialog(view, "Usuário removido com Sucesso!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(view, "Falha de conexão!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}


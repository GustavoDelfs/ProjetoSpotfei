package controller;

import DAO.BD_Link;
import DAO.HistoricoDAO;
import View.MenuFrame;
import dao.MusicDAO;
import model_.Musica;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ControllerMusic {
    private MenuFrame view;
    private List<Musica> musicasAtuais;

    public ControllerMusic(MenuFrame view) {
        this.view = view;
        this.musicasAtuais = new ArrayList<>();

        inicializarTabela();
        adicionarEventosTabela();
    }

    private void inicializarTabela() {
        DefaultTableModel modeloVazio = new DefaultTableModel(new Object[][]{}, new String[]{});
        JTable tabela = view.getTbl_exibir_msc();
        tabela.setModel(modeloVazio);
        tabela.getTableHeader().setUI(null); // remove o cabeçalho visual
    }

    public void obterMusicas() {
        String filtro = view.getTxt_buscar_musica().getText().trim();
        JTable tabela = view.getTbl_exibir_msc();

        if (filtro.isEmpty()) {
            DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
            modelo.setRowCount(0);
            return;
        }

        BD_Link bd_link = new BD_Link();
        try {
            Connection conn = bd_link.getConnection();
            MusicDAO dao = new MusicDAO(conn);

            this.musicasAtuais = dao.listarMusicas(filtro);

            DefaultTableModel modelo = new DefaultTableModel(
                    new Object[]{"Título", "Artista", "Curtido", "Detalhes"}, 0) {

                Class[] colunas = new Class[]{
                        String.class, String.class, Boolean.class, Object.class
                };

                @Override
                public Class<?> getColumnClass(int col) {
                    return colunas[col];
                }

                @Override
                public boolean isCellEditable(int row, int col) {
                    return col == 2; // apenas "curtido" é editável
                }
            };

            for (Musica m : musicasAtuais) {
                modelo.addRow(new Object[]{
                        m.getTitulo(),
                        m.getArtista(),
                        m.getCurtido(),
                        "Detalhes"
                });
            }

            tabela.setModel(modelo);
            tabela.getTableHeader().setUI(null);

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(view,
                    "Erro ao buscar músicas: " + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void adicionarEventosTabela() {
        JTable tabela = view.getTbl_exibir_msc();

        tabela.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = tabela.rowAtPoint(e.getPoint());
                int col = tabela.columnAtPoint(e.getPoint());

                if (row >= 0) {
                    Musica musicaSelecionada = musicasAtuais.get(row);
                    int idMusica = musicaSelecionada.getId();
                    int idUsuario = ControllerLogin.getUsuarioLogado().getId();

                    BD_Link bd_link = new BD_Link();
                    try (Connection conn = bd_link.getConnection()) {
                        HistoricoDAO historicoDAO = new HistoricoDAO(conn);

                        // Sempre salva a busca
                        historicoDAO.salvarHistoricoBusca(idUsuario, idMusica);

                        if (col == 2) { // coluna "Curtido"
                            alternarCurtido(row);
                        } else if (col == 3) { // coluna "Detalhes"
                            mostrarDetalhesMusica(row);
                        }

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
    }

    private void alternarCurtido(int indice) {
    JTable tabela = view.getTbl_exibir_msc();
    Boolean curtidoAtual = (Boolean) tabela.getValueAt(indice, 2);
    Boolean novoValor = !curtidoAtual;

    tabela.setValueAt(novoValor, indice, 2);
    Musica musica = musicasAtuais.get(indice);
    musica.setCurtido(novoValor);

    BD_Link bd_link = new BD_Link();
    try (Connection conn = bd_link.getConnection()) {
        MusicDAO dao = new MusicDAO(conn);
        dao.atualizarCurtido(musica.getId(), novoValor);

        // Novo: salvar no histórico
        HistoricoDAO historicoDAO = new HistoricoDAO(conn);
        int idUsuario = ControllerLogin.getUsuarioLogado().getId();
        if (novoValor) {
            historicoDAO.salvarHistoricoCurtida(idUsuario, musica.getId());
        } else {
            historicoDAO.salvarHistoricoDescurtida(idUsuario, musica.getId());
        }
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(view,
                "Erro ao atualizar curtida no banco: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
    }
}


    private void mostrarDetalhesMusica(int indice) {
        if (indice < 0 || indice >= musicasAtuais.size()) return;

        Musica m = musicasAtuais.get(indice);

        String detalhes = String.format(
                "🎵 Título: %s\n🎤 Artista: %s\n🎧 Gênero: %s\n⏱ Duração: %s\n📅 Postagem: %s\n👁 Visualizações: %d",
                m.getTitulo(),
                m.getArtista(),
                m.getGenero(),
                m.getDuracao(),
                m.getDataPostagem(),
                m.getVisualizacoes()
        );

        JOptionPane.showMessageDialog(view, detalhes,
                "Detalhes da Música", JOptionPane.INFORMATION_MESSAGE);
    }
}

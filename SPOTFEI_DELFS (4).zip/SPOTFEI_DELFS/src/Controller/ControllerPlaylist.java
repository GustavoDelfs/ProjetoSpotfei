package Controller;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import DAO.BD_Link;
import DAO.PlaylistDAO;
import model_.Playlist;
import View.GerenciadorPlaylistFrame;
import controller.ControllerLogin;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ControllerPlaylist {
    private GerenciadorPlaylistFrame view;
    private PlaylistDAO playlistDAO;

    public ControllerPlaylist(GerenciadorPlaylistFrame view) {
        this.view = view;
        BD_Link bd_link = new BD_Link();
        try {
            Connection conn = bd_link.getConnection();
            playlistDAO = new PlaylistDAO(conn);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar com o banco de dados.");
        }
    }

    public boolean adicionarMusica(int idPlaylist, String tituloMusica) {
        return playlistDAO.adicionarMusicaNaPlaylist(idPlaylist, tituloMusica);
    }

    public boolean excluirPlaylist(int idPlaylist) {
        return playlistDAO.excluirPlaylist(idPlaylist);
    }

    public boolean editarNomePlaylist(String nomeAtual, String novoNome) {
        return playlistDAO.editarNomePlaylist(nomeAtual, novoNome);
    }

    public void configurarTabelaPlaylist(JTable tabela) {
        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = tabela.rowAtPoint(e.getPoint());
                int col = tabela.columnAtPoint(e.getPoint());
                String nomePlaylist = (String) tabela.getValueAt(row, 0);
                int idPlaylist = playlistDAO.obterIdPorNome(nomePlaylist);

                if (col == 1) { // Adicionar Música
                    String titulo = solicitarTituloMusicaViaDialog();
                    if (titulo != null) {
                        boolean ok = adicionarMusica(idPlaylist, titulo);
                        JOptionPane.showMessageDialog(null, ok ? "Música adicionada." : "Erro ao adicionar música.");
                    }

                } else if (col == 2) { // Excluir Música
                    String titulo = solicitarTituloMusicaViaDialog();
                    if (titulo != null) {
                        boolean ok = playlistDAO.excluirMusicaDaPlaylist(idPlaylist, titulo);
                        JOptionPane.showMessageDialog(null, ok ? "Música removida." : "Erro ao remover música.");
                    }

                } else if (col == 3) { // Editar nome
                    String novoNome = JOptionPane.showInputDialog("Novo nome:");
                    if (novoNome != null && !novoNome.trim().isEmpty()) {
                        boolean ok = editarNomePlaylist(nomePlaylist, novoNome);
                        if (ok) {
                            tabela.setValueAt(novoNome, row, 0);
                        } else {
                            JOptionPane.showMessageDialog(null, "Erro ao renomear playlist.");
                        }
                    }

                } else if (col == 4) { // Excluir Playlist
                    int opcao = JOptionPane.showConfirmDialog(null, "Excluir playlist?");
                    if (opcao == JOptionPane.YES_OPTION) {
                        boolean ok = playlistDAO.excluirPlaylistPorNome(nomePlaylist);
                        if (ok) {
                            ((DefaultTableModel) tabela.getModel()).removeRow(row);
                        } else {
                            JOptionPane.showMessageDialog(null, "Erro ao excluir playlist.");
                        }
                    }
                }
            }
        });
    }

    private String solicitarTituloMusicaViaDialog() {
        String input = JOptionPane.showInputDialog("Digite o TÍTULO da música:");
        if (input != null && !input.trim().isEmpty()) {
            return input.trim();
        } else {
            JOptionPane.showMessageDialog(null, "Título inválido.");
            return null;
        }
    }

   public void carregarTabelaPlaylists(JTable tabela) {
    try {
        int idUsuario = ControllerLogin.getUsuarioLogado().getId(); // ✅ ID do usuário logado
        List<Playlist> playlists = playlistDAO.listarPlaylistsPorUsuario(idUsuario);

        DefaultTableModel model = (DefaultTableModel) tabela.getModel();
        model.setRowCount(0); // Limpa tabela antes de inserir

        tabela.setTableHeader(null); // Remove cabeçalho

        for (Playlist p : playlists) {
            model.addRow(new Object[] {
                p.getNome(), "Adicionar Música", "Excluir Música", "Editar Nome", "Excluir"
            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Erro ao carregar playlists: " + e.getMessage());
    }
}

    
    
}

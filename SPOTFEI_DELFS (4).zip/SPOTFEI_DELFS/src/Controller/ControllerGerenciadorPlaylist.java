package Controller;

import DAO.BD_Link;
import DAO.PlaylistDAO;
import model_.Playlist;
import View.CriarPlaylistFrame;
import controller.ControllerLogin;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ControllerGerenciadorPlaylist {
    private CriarPlaylistFrame view;
    private PlaylistDAO playlistDAO;

    public ControllerGerenciadorPlaylist(CriarPlaylistFrame view) {
        this.view = view;
        BD_Link bd_link = new BD_Link();
        try {
            Connection conn = bd_link.getConnection();
            playlistDAO = new PlaylistDAO(conn);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar com o banco de dados.");
        }

        this.view.getCriar_playlist().addActionListener(e -> criarPlaylist());

      
    }

   private void criarPlaylist() {
    String nome = view.getTxt_nome_nova_playlist().getText();
    if (nome == null || nome.trim().isEmpty()) {
        JOptionPane.showMessageDialog(view, "Digite o nome da playlist.");
        return;
    }

    int idUsuario = ControllerLogin.getUsuarioLogado().getId();

    Playlist playlist = new Playlist(nome, idUsuario); // ✅ CORRETO
    boolean sucesso = playlistDAO.salvar(playlist);

    if (sucesso) {
        JOptionPane.showMessageDialog(view, "Playlist criada com sucesso!");
        view.getTxt_nome_nova_playlist().setText("");

    } else {
        JOptionPane.showMessageDialog(view, "Erro ao criar playlist.");
    }
}

}

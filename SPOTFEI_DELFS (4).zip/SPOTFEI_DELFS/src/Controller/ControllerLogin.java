package controller;

import DAO.UserDAO;
import DAO.BD_Link;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model_.User;
import View.AltExcFrame;
import View.LoginFrame;

public class ControllerLogin {
    private LoginFrame view;

    // Variável estática para armazenar o usuário logado (pode ser só o id, ou o objeto completo)
    private static User usuarioLogado;

    public ControllerLogin(LoginFrame view) {
        this.view = view;
    }
    
    public void loginAluno() {
        User usuario = new User("", 
                                view.getTxt_usuario_login().getText(),
                                view.getTxt_senha_login().getText());
        BD_Link bd_link = new BD_Link();
        try {
            Connection conn = bd_link.getConnection();
            UserDAO dao = new UserDAO(conn);
            ResultSet res = dao.consultar(usuario);
            if(res.next()) {
                // Pega o id, nome, usuário e senha do resultado
                int id = res.getInt("id_usuario"); // supondo que a coluna id exista
                String nome = res.getString("nome");
                String usuarioBanco = res.getString("usuario");
                String senha = res.getString("senha");

                // Cria o usuário com o id
                usuarioLogado = new User(id, nome, usuarioBanco, senha);

                JOptionPane.showMessageDialog(view, 
                                              "Login efetuado!", 
                                              "Aviso",
                                              JOptionPane.INFORMATION_MESSAGE);

                AltExcFrame aec = new AltExcFrame(usuarioLogado);
                aec.setVisible(true);

                // Aqui você pode fechar o LoginFrame, se quiser:
                view.dispose();

            } else {
                JOptionPane.showMessageDialog(view, 
                                              "Login NÃO efetuado!", 
                                              "Aviso",
                                              JOptionPane.ERROR_MESSAGE);
            }
        } catch(SQLException e) {    
            e.printStackTrace(); 
            JOptionPane.showMessageDialog(view, 
                                              "Erro de conexão!", 
                                              "Aviso",
                                              JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para recuperar o usuário logado em qualquer lugar
    public static User getUsuarioLogado() {
        return usuarioLogado;
    }
}

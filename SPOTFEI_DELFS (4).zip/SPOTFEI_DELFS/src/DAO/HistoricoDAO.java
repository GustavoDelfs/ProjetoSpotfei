package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HistoricoDAO {
    private Connection conn;

    public HistoricoDAO(Connection conn) {
        this.conn = conn;
    }

    // Salvar busca no histórico
    public void salvarHistoricoBusca(int idUsuario, int idMusica) throws SQLException {
        String sql = "INSERT INTO historico_buscas (id_usuario, id_musica,momento) VALUES (?, ?, NOW())";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            stmt.setInt(2, idMusica);
            stmt.executeUpdate();
        }
    }
    
    public void salvarHistoricoCurtida(int idUsuario, int idMusica) throws SQLException {
    String sql = "INSERT INTO historico_curtidas (id_usuario, id_musica) VALUES (?, ?)";
    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, idUsuario);
        stmt.setInt(2, idMusica);
        stmt.executeUpdate();
    }
}
   public void salvarHistoricoDescurtida(int idUsuario, int idMusica) throws SQLException {
    String sql = "INSERT INTO historico_descurtidas (id_usuario, id_musica, momento) VALUES (?, ?, current_timestamp)";
    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, idUsuario);
        stmt.setInt(2, idMusica);
        stmt.executeUpdate();
    }
}



    // Últimas 10 buscas
    public List<String> getUltimasBuscas(int idUsuario) throws SQLException {
        String sql = """
                SELECT m.titulo
                FROM historico_buscas hb
                JOIN musica m ON hb.id_musica = m.id_musica
                WHERE hb.id_usuario = ?
                ORDER BY hb.momento DESC
                LIMIT 10
            """;

        List<String> historico = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                historico.add("🔍 " + rs.getString("titulo"));
            }
        }
        return historico;
    }

    // Últimas 10 curtidas
    public List<String> getUltimasCurtidas(int idUsuario) throws SQLException {
        String sql = """
                SELECT m.titulo
                FROM historico_curtidas c
                JOIN musica m ON c.id_musica = m.id_musica
                WHERE c.id_usuario = ? AND m.curtido = true
                ORDER BY c.momento DESC
                LIMIT 10
            """;

        List<String> historico = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                historico.add("❤️ " + rs.getString("titulo"));
            }
        }
        return historico;
    }

    // Últimas 10 descurtidas
    public List<String> getUltimasDescurtidas(int idUsuario) throws SQLException {
        String sql = """
                SELECT m.titulo
                FROM historico_descurtidas z
                JOIN musica m ON z.id_musica = m.id_musica
                WHERE z.id_usuario = ? 
                ORDER BY z.momento DESC
                LIMIT 10
            """;

        List<String> historico = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                historico.add("💔 " + rs.getString("titulo"));
            }
        }
        return historico;
    }
}




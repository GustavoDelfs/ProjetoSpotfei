package DAO;

import java.util.ArrayList;
import java.util.List;
import model_.Playlist;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PlaylistDAO {
    private Connection connection;

    public PlaylistDAO(Connection connection) {
        this.connection = connection;
    }
    
    public List<Playlist> listarPorUsuario(int idUsuario) throws SQLException {
    List<Playlist> lista = new ArrayList<>();
    String sql = "SELECT * FROM playlist WHERE id_usuario = ?";
    
    try (PreparedStatement stmt = connection .prepareStatement(sql)) {
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {
            Playlist p = new Playlist(
                rs.getString("nome"),
                rs.getInt("id_usuario")
            );
            lista.add(p);
        }
    }

    return lista;
}

    
    public boolean salvar(Playlist playlist) {
        String sql = "INSERT INTO playlist (nome, id_usuario) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, playlist.getNome());
            stmt.setInt(2, playlist.getIdUsuario());
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean adicionarMusicaNaPlaylist(int idPlaylist, String tituloMusica) {
    String sql = """
        INSERT INTO playlist_musica (id_playlist, id_musica)
        VALUES (?, (SELECT id_musica FROM musica WHERE titulo = ?))
    """;

    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1, idPlaylist);
        stmt.setString(2, tituloMusica);
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


    public boolean excluirPlaylistPorNome(String nome) {
        String sql = "DELETE FROM playlist WHERE nome = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nome);
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean editarNomePlaylist(String nomeAtual, String novoNome) {
        String sql = "UPDATE playlist SET nome = ? WHERE nome = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, novoNome);
            stmt.setString(2, nomeAtual);
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int obterIdPorNome(String nome) {
        String sql = "SELECT id_playlist FROM playlist WHERE nome = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nome);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_playlist");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // não encontrado ou erro
    }
    
   public boolean excluirMusicaDaPlaylist(int idPlaylist, String tituloMusica) {
    String sql = """
        DELETE FROM playlist_musica 
        WHERE id_playlist = ? 
          AND id_musica = (SELECT id_musica FROM musica WHERE titulo = ?)
    """;

    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1, idPlaylist);
        stmt.setString(2, tituloMusica);
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
} 
    
    

    public List<Playlist> listarPlaylistsPorUsuario(int idUsuario) throws SQLException {
        List<Playlist> playlists = new ArrayList<>();
        String sql = "SELECT id_playlist, nome, id_usuario FROM playlist WHERE id_usuario = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, idUsuario);
                ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Playlist p = new Playlist();
            p.setNome(rs.getString("nome"));
            p.setIdUsuario(rs.getInt("id_usuario"));
            playlists.add(p);
        }
    }
    return playlists;
}


    public boolean excluirPlaylist(int idPlaylist) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}

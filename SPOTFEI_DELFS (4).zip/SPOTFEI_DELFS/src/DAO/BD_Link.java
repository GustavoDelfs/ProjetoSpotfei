package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BD_Link {
    public Connection getConnection() throws SQLException{
        Connection bd_link = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/Projeto-Spotfei",
                "postgres", "Delfino@010967");
        return bd_link;
    }
}

package dao;

import model_.Musica;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MusicDAO {

    private Connection conn;

    public MusicDAO(Connection conn) {
        this.conn = conn;
    }
    
    public void atualizarCurtido(int idMusica, boolean curtido) throws SQLException {
    String sql = "UPDATE musica SET curtido = ? WHERE id_musica = ?";
    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setBoolean(1, curtido);
    stmt.setInt(2, idMusica);
    stmt.executeUpdate();
    stmt.close();
}
    
    public List<String> listarUltimasBuscas(int idUsuario) throws SQLException {
    List<String> historico = new ArrayList<>();
    String sql = "SELECT titulo_musica FROM historico_buscadas WHERE id_usuario = ? ORDER BY data_busca DESC LIMIT 10";
    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            historico.add(rs.getString("titulo_musica"));
        }
    }
    return historico;
}

    public List<Musica> listarMusicas(String filtro) throws SQLException {
    List<Musica> musicas = new ArrayList<>();
    String sql = """
        SELECT m.id_musica, m.titulo, a.nome AS artista_nome, g.nome AS genero_nome,
               m.duracao, m.visualizacoes, m.data_postagem, m.curtido
        FROM musica m
        JOIN artista a ON m.id_artista = a.id
        JOIN genero g ON m.id_genero = g.id
        WHERE m.titulo ILIKE ?
           OR a.nome ILIKE ?
           OR g.nome ILIKE ?
    """;

    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        String likeFiltro = "%" + filtro + "%";
        stmt.setString(1, likeFiltro);
        stmt.setString(2, likeFiltro);
        stmt.setString(3, likeFiltro);

        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Musica m = new Musica(
                    rs.getInt("id_musica"),
                    rs.getString("titulo"),
                    rs.getString("artista_nome"),
                    rs.getString("genero_nome"),
                    rs.getString("duracao"),
                    rs.getInt("visualizacoes"),
                    rs.getString("data_postagem"),
                    rs.getBoolean("curtido")
                );
                musicas.add(m);
            }
        }
    }

    return musicas;
 }
}
package main;

import View.LoginFrame;
//import View.MenuFrame;
//import View.CriarPlaylistFrame;
//import View.GerenciadorPlaylistFrame;
//import View.HistoricoFrame;

public class SPOTFEI_DELFS {

    public static void main(String[] args) {
//        CriarPlaylistFrame cf = new CriarPlaylistFrame();
//        cf.setVisible(true);
//        HistoricoFrame hf = new HistoricoFrame();
//        hf.setVisible(true);
//        GerenciadorPlaylistFrame gf = new GerenciadorPlaylistFrame();
//        gf.setVisible(true);;
//        MenuFrame mf = new MenuFrame();;
//        mf.setVisible(true);
        LoginFrame lf = new LoginFrame();;
        lf.setVisible(true);
    }
  
}
